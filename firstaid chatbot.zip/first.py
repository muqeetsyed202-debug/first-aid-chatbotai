import json
import pickle
import random
import traceback
import numpy as np
import nltk
from nltk.stem import WordNetLemmatizer
import streamlit as st
from tensorflow.keras.models import load_model

try:
    # ✅ Download required NLTK resources
    nltk.download('punkt', quiet=True)
    nltk.download('wordnet', quiet=True)
    nltk.download('omw-1.4', quiet=True)

    lemmatizer = WordNetLemmatizer()

    # --- Load files ---
    with open('intents.json') as f:
        intents = json.load(f)

    with open('words.pkl', 'rb') as f:
        words = pickle.load(f)

    with open('classes.pkl', 'rb') as f:
        classes = pickle.load(f)

    model = load_model('chatbot_model.keras')

    # --- Chatbot Functions ---
    def clean_up_sentence(sentence):
        tokens = nltk.word_tokenize(sentence)
        return [lemmatizer.lemmatize(t.lower()) for t in tokens]

    def bag_of_words(sentence):
        sentence_words = clean_up_sentence(sentence)
        bag = [1 if w in sentence_words else 0 for w in words]
        return np.array([bag], dtype=np.float32)

    def predict_intent(sentence, confidence_threshold=0.5):
        bag = bag_of_words(sentence)
        prediction = model.predict(bag, verbose=0)[0]
        best_index = int(np.argmax(prediction))
        best_confidence = float(prediction[best_index])
        
        if best_confidence < confidence_threshold:
            return None, best_confidence
        return classes[best_index], best_confidence

    def get_response(tag):
        for intent in intents['intents']:
            if intent['tag'] == tag:
                responses = intent['responses']
                selected_response = random.choice(responses).strip()
                
                # Check if the response in intents.json is empty or blank spaces
                if not selected_response:
                    return "I don't have detailed first-aid instructions for this specific condition yet. Please consult a healthcare professional."
                return selected_response
                
        return "I'm not sure how to respond to that."

    # --- Streamlit UI ---
    st.set_page_config(page_title="FirstAid Assistant", page_icon="🚑")
    st.title("🚑 FirstAid Care Bot")
    st.write(
        "Ask questions about immediate first-aid procedures for common injuries and medical emergencies.\n\n"
        "⚠️ **Disclaimer:** *This bot is for informational purposes only and is not a substitute for professional emergency medical services. In case of a serious medical emergency, contact your local emergency services immediately.*"
    )

    if "chat_history" not in st.session_state:
        st.session_state.chat_history = [
            {
                "role": "assistant", 
                "content": "Hello! I am your FirstAid Assistant. How can I help you today? (e.g., Ask about cuts, burns, sprains, CPR, etc.)"
            }
        ]

    # Render previous messages
    for message in st.session_state.chat_history:
        with st.chat_message(message["role"]):
            st.write(message["content"])

    # User input chat widget
    user_input = st.chat_input("Ask a first-aid question (e.g., What to do for a cut?)...")

    if user_input:
        # Display user query
        st.session_state.chat_history.append({"role": "user", "content": user_input})
        with st.chat_message("user"):
            st.write(user_input)

        # Predict intent & get response
        tag, confidence = predict_intent(user_input)
        
        if tag is None:
            reply = "I'm not confident I understood that. Could you rephrase your query or describe the injury?"
        else:
            reply = get_response(tag)

        # Display assistant reply
        st.session_state.chat_history.append({"role": "assistant", "content": reply})
        with st.chat_message("assistant"):
            st.write(reply)
            st.caption(
                f"Detected condition: `{tag}` (confidence: {confidence:.2f})"
                if tag else f"Low confidence score: {confidence:.2f}"
            )

except Exception as e:
    st.error(f"⚠️ Error while running the app: {e}")
    st.text(traceback.format_exc())